class AppImages {
  static const String basePath = 'assets/images/';

  static const String logo = '${basePath}applogo.png';
  static const String getStarted = '${basePath}getstarted.png';
}
