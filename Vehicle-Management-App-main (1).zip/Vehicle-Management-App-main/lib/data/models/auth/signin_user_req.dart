class SigninUserReq {
  final String email;
  final String password;

  SigninUserReq({
    required this.email,
    required this.password
  });
}